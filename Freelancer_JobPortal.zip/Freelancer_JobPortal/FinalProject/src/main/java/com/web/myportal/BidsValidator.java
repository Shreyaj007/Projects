package com.web.myportal;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.web.myportal.pojo.AdvertProject;
import com.web.myportal.pojo.Bids;

public class BidsValidator implements Validator{


	   public boolean supports(Class aClass)
	    {
	        return aClass.equals(Bids.class);
	    }

	@Override
	public void validate(Object obj, Errors errors) {
		// TODO Auto-generated method stub
		
		
		  Bids bids = (Bids) obj;
	       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "bidamount", "error.invalid.advertproject", "Bid Amount Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "timeRequired", "error.invalid.advertproject", "Time Required"); 
		
		
	}
	
	
	
}
