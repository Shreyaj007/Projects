package com.web.myportal;

import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.myportal.dao.ProjectDAO;
import com.web.myportal.dao.UserDAO;
import com.web.myportal.exception.AdException;
import com.web.myportal.pojo.AdvertProject;
import com.web.myportal.pojo.Bids;
import com.web.myportal.pojo.Category;
import com.web.myportal.pojo.User;

@Controller
//@RequestMapping("/adduser.htm")
public class PostProjectController {

	@Autowired
	@Qualifier("projectValidator")
	ProjectValidator validatorr;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validatorr);
	}

	@RequestMapping(value="/postProject.htm",method = RequestMethod.POST)
	protected ModelAndView doSubmitAction(@ModelAttribute("advertproject")AdvertProject advertproject, BindingResult result,HttpServletRequest req) throws Exception {
		
		ModelAndView mv = new ModelAndView();
		validatorr.validate(advertproject, result);
		if (result.hasErrors()) {
			
			System.out.println("validator");
			mv.setViewName("PostProject");
			return mv;
		}
		
		
		String numregex = "^[0-9]+$";
		String textregex = "^[a-zA-Z\\s]+$";
		
		Pattern patternText = Pattern.compile(textregex);
		Pattern patternBidAmt = Pattern.compile(numregex);
		
		Matcher matcherDescptn = patternText.matcher(advertproject.getDescription());
		Matcher matcherPrjName = patternText.matcher(advertproject.getProjectname());
		 Matcher matcher = patternBidAmt.matcher(String.valueOf(advertproject.getBudget()));
		
		 boolean matches = (matcher.matches() && matcherDescptn.matches() && matcherPrjName.matches());
		
		if(matches)
		{

		//try {
			System.out.println("test");
			ProjectDAO projectDao = new ProjectDAO();
			System.out.print("test1");
			
			HttpSession sessionhttp = req.getSession(false);
			//AdvertProject advertprojectt = new AdvertProject(advertproject.getCategoryname(), advertproject.getProjectname(),advertproject.getDescription(),advertproject.getBudget());
	            
			 
			 User u = (User)sessionhttp.getAttribute("user");		
			 
			 User user1 = new User(u.getUsername(), u.getPassword());
			 user1.setEmail(u.getEmail());
			 user1.setFirstName(u.getFirstName());
			 user1.setLastName(u.getLastName());
			 user1.setPersonID(u.getPersonID());
			 user1.setRole(u.getRole());
			 
			 
			 advertproject.setUser(user1);
			advertproject.setStatus("posted/pendingApproval");
//	        Category category = projectDao.get(advertproject);
			
			//userDao.create(user.getName(), user.getPassword(), user.getEmail(), user.getFirstName(), user.getLastName());
			
			projectDao.create(advertproject);
		//	mv.addObject("user", user1);
			mv.addObject("userInSession", user1.getPersonID());
			mv.setViewName("projectposted");
		}
		else
		{
			mv.setViewName("error");
			// DAO.close();
//		} catch (Exception e) {
//			System.out.println("Exception: " + e.getMessage());
//		}
		}
		return mv;
	}
	
	
	@RequestMapping(value="/postProject.htm",method = RequestMethod.GET)
	public ModelAndView initializeSignInForm(@ModelAttribute("advertproject") AdvertProject advertproject, HttpServletRequest req) {

		ProjectDAO prj = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
		List catlist = null;
		try {
			catlist = prj.getCategoryList();
			System.out.println(catlist.size());
			Iterator categIterator = catlist.iterator();
			while(categIterator.hasNext())
			{
			Category category = (Category)categIterator.next();
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		HttpSession sessionhttp = req.getSession(false);
		 
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		
		
		
		mv.addObject("catlist",catlist);	
	//	mv.addObject("user", user1);
		
		mv.addObject("userInSession", user1.getPersonID());
		mv.setViewName("PostProject");
		
		return mv;
		
	}
	
	@RequestMapping(value="/browseProject.htm",method = RequestMethod.GET)
	protected ModelAndView doBrowseAction(HttpServletRequest req) {
		
		ProjectDAO projectdao = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
		HttpSession sessionhttp = req.getSession(false);		
		
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		
		try {
			List<AdvertProject> list = projectdao.browse(user1.getPersonID());
			mv.addObject("projectlist", list);
			System.out.println("projectlist");
			mv.addObject("userInSession", user1.getPersonID());
						
			
			mv.setViewName("showProjects");
		} catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return mv;
	}
	
//	
//	@RequestMapping(value="/showAllProjects.htm",method = RequestMethod.GET)
//	protected ModelAndView doBrowse(HttpServletRequest req) {
//		
//		ProjectDAO projectdao = new ProjectDAO();
//		ModelAndView mv = new ModelAndView();
//		HttpSession sessionhttp = req.getSession(false);		
//		
//		 User u = (User)sessionhttp.getAttribute("user");		
//		 
//		 User user1 = new User(u.getUsername(), u.getPassword());
//		 user1.setEmail(u.getEmail());
//		 user1.setFirstName(u.getFirstName());
//		 user1.setLastName(u.getLastName());
//		 user1.setPersonID(u.getPersonID());
//		 user1.setRole(u.getRole());
//		
//		try {
//			List<AdvertProject> list = projectdao.browseAll(user1.getPersonID());
//			mv.addObject("projectlist", list);
//			System.out.println("projectlist");
//			mv.addObject("userInSession", user1.getPersonID());
//						
//			
//			mv.setViewName("displayProjects");
//		} catch (AdException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//				
//		return mv;
//	}
//	
//	
	
	
	
//	@RequestMapping(value="/assignProject.htm",method = RequestMethod.GET)
//	protected ModelAndView assignProjectAction(HttpServletRequest req) {
//		
//		ProjectDAO projectdao = new ProjectDAO();
//		ModelAndView mv = new ModelAndView();
//		HttpSession sessionhttp = req.getSession(false);		
//		
//		 User u = (User)sessionhttp.getAttribute("user");		
//		 
//		 User user1 = new User(u.getUsername(), u.getPassword());
//		 user1.setEmail(u.getEmail());
//		 user1.setFirstName(u.getFirstName());
//		 user1.setLastName(u.getLastName());
//		 user1.setPersonID(u.getPersonID());
//		 user1.setRole(u.getRole());
//		
//		try {
//			List<AdvertProject> list = projectdao.browse(user1.getPersonID());
//			mv.addObject("projectlist", list);
//			System.out.println("projectlist");
//			
//			mv.setViewName("showProjects");
//		} catch (AdException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//				
//		return mv;
//	}

	
	@RequestMapping(value="abc.htm",method = RequestMethod.GET)
	protected ModelAndView assignProjectsAction( HttpServletRequest req) {
		
		ProjectDAO projectdao = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
		HttpSession sessionhttp = req.getSession(false);		
		long projectid = Long.parseLong(req.getParameter("projectid"));
		long userid = Long.parseLong(req.getParameter("biduser"));
		
		System.out.println("biduser "+userid);
		
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		 		 
		try {
			
			AdvertProject advprj = projectdao.getProjectByPid(projectid);
					//projectdao.getProject(user1.getPersonID());	
			
			advprj.setStatus("Assigned");
			advprj.setUserAssigned(userid);
			projectdao.assignProject(advprj);
			
			mv.addObject("userInSession", user1.getPersonID());
						
			mv.setViewName("displayMyProjects");
		} catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return mv;
	}

	
	@RequestMapping(value="/myProjects.htm",method = RequestMethod.GET)
	protected ModelAndView showMyProjects(HttpServletRequest req) {
		
		ProjectDAO projectdao = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
		
		HttpSession sessionhttp = req.getSession(false);		
		
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());	
				
		try {
			List<AdvertProject> list = projectdao.getProjectAssigned(user1.getPersonID());
			mv.addObject("projectlist", list);
			System.out.println("projectlist");
			mv.addObject("userInSession", user1.getPersonID());
							
			mv.setViewName("displayMyProjects");
		} catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return mv;
	}
	
	
	@RequestMapping(value="/completeProject.htm",method = RequestMethod.GET)
	protected ModelAndView completeProjects(HttpServletRequest req) {
		
		ProjectDAO projectdao = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
		long projectid = Long.parseLong(req.getParameter("projectid"));
		
		HttpSession sessionhttp = req.getSession(false);		
		
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		
		try {
			
			AdvertProject advprj = projectdao.getProjectByPid(projectid);
			advprj.setStatus("completed");
		//	List<AdvertProject> list = projectdao.browse(userid);
			projectdao.completeProject(advprj);
			List<AdvertProject> list = projectdao.onCompletion(user1.getPersonID());
			mv.addObject("projectlist", list);
			System.out.println("projectlist");
		//	mv.addObject("userInSession", user1.getPersonID());
								
			mv.setViewName("displayMyProjects");
		} catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return mv;
	}
	
	@RequestMapping(value="/postedProjects.htm",method = RequestMethod.GET)
	protected ModelAndView postedProjectProgress(HttpServletRequest req) {
		
		ProjectDAO projectdao = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
		//long projectid = Long.parseLong(req.getParameter("projectid"));
		
		HttpSession sessionhttp = req.getSession(false);		
		
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		
		try {
			
//			AdvertProject advprj = projectdao.getProjectByPid(projectid);

			List<AdvertProject> list = projectdao.getProjectPosted(user1.getPersonID());
			mv.addObject("projectlist", list);
			System.out.println("projectlist");
		//	mv.addObject("userInSession", user1.getPersonID());
								
			mv.setViewName("projectProgress");
		} catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return mv;
	}
	
	
}
