package com.web.myportal.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;

import com.web.myportal.exception.AdException;
import com.web.myportal.pojo.AdvertProject;
import com.web.myportal.pojo.Bids;
import com.web.myportal.pojo.Category;
import com.web.myportal.pojo.User;




public class ProjectDAO extends DAO{

	 public ProjectDAO() {
	    }
	
	    public AdvertProject create(AdvertProject advertproject )
	            throws Exception{
	        try {
	            begin();
	           
	            getSession().save(advertproject);
	            
	            commit();
	            return advertproject;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	        
	    public List browseAll( )
	            throws AdException{
	        try {
	            begin();	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            
	           // Query q = getSession().createQuery("from AdvertProject where user != :userid ");
	          //  Query q = getSession().createQuery("from AdvertProject where user = :userid ");
	            Query q = getSession().createQuery("from AdvertProject ");
	           // q.setLong("userid", userid);
	            //User user = (User) q.uniqueResult();
	            
	            List<AdvertProject> projectlist = q.list();
	            commit();
	            return projectlist;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    
	    public List browse(long userid )
	            throws AdException{
	        try {
	            begin();	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            
	           // Query q = getSession().createQuery("from AdvertProject where user != :userid ");
	          //  Query q = getSession().createQuery("from AdvertProject where user = :userid ");
	            Query q = getSession().createQuery("from AdvertProject where status = 'Approved' or status = 'Bid Placed'");
	           // q.setLong("userid", userid);
	            //User user = (User) q.uniqueResult();
	            
	            List<AdvertProject> projectlist = q.list();
	            commit();
	            return projectlist;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    
	    
	    
	    
	    public List browseBids( long projectid)
	            throws AdException{
	        try {
	            begin();
	            System.out.println("pr "+projectid);
	            
	            Query q = getSession().createQuery("from Bids where projectid = :projectid");
	            q.setLong("projectid", projectid);
	            //User user = (User) q.uniqueResult();
	            
	            List bidlist = q.list();
	            System.out.println("size "+ bidlist.size());
	            commit();
	            return bidlist;
	        } catch (HibernateException e) {
	        	
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	            
	        }
	    }
	    
	    
	    
	    
	    
	    
	    public List getCategoryList()
	            throws Exception {
	        try {
	            begin();
	            Query q = getSession().createQuery("from Category ");
	            //q.setString("username", username);
	           // User user = (User) q.uniqueResult();
	            List catlist = q.list();
	            commit();
	            return catlist;
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not get list");
	        }
	    }
	    
	    public Bids placeBid(Bids bids)
	            throws AdException{
	        try {
	            begin();
	            
	            //Bids bids = new Bids(bidamount, bidtime,projectid);
	          
	            System.out.println("new bids");
	            getSession().save(bids);
	            commit();
	            return bids;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            e.printStackTrace();
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	            
	        }
	    }
	 
	    public void assignProject(AdvertProject project)
	            throws Exception {
	        try {
	            begin();
	            System.out.println("inside DAO");
	            
	            getSession().update(project);
	            
	            System.out.println(" saved user ");
	            
	            commit();
	           // return project;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create user " + username, e);
	            throw new Exception("Exception while creating user: " + e.getMessage());
	        }
	    }
	    
	    
	    public AdvertProject getProject(long userid )
	            throws AdException{
	        try {
	            begin();
	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            System.out.println("userid "+userid);
	            Query q = getSession().createQuery("from AdvertProject where user = :userid ");
	            q.setLong("userid", userid);
	            AdvertProject advertprj = (AdvertProject) q.uniqueResult();
	            
	            //List<AdvertProject> projectlist = q.list();
	            commit();
	            return advertprj;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    public AdvertProject getProjectByPid(long projectid )
	            throws AdException{
	        try {
	            begin();
	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            
	            Query q = getSession().createQuery("from AdvertProject where projectid = :projectid ");
	            q.setLong("projectid", projectid);
	            AdvertProject advertprj = (AdvertProject) q.uniqueResult();
	            
	            //List<AdvertProject> projectlist = q.list();
	            commit();
	            return advertprj;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    
	    public List getProjectToBeApproved( )
	            throws AdException{
	        try {
	            begin();
	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            
	            Query q = getSession().createQuery("from AdvertProject where status = 'posted/pendingApproval' ");
	           // q.setLong("projectid", projectid);
	          //  AdvertProject advertprj = (AdvertProject) q.uniqueResult();
	            
	            List<AdvertProject> projectlist = q.list();
	            commit();
	            return projectlist;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    
	    public List getProjectApproved( )
	            throws AdException{
	        try {
	            begin();
	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            
	            Query q = getSession().createQuery("from AdvertProject where status = 'Approved' ");
	           // q.setLong("projectid", projectid);
	          //  AdvertProject advertprj = (AdvertProject) q.uniqueResult();
	            
	            List<AdvertProject> projectlist = q.list();
	            commit();
	            return projectlist;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    
	    
	    public void approveProject(AdvertProject project)
	            throws Exception {
	        try {
	            begin();
	            System.out.println("inside DAO");
	            
	            getSession().update(project);
	            
	           
	            
	            commit();
	           // return project;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create user " + username, e);
	            throw new Exception("Exception while creating user: " + e.getMessage());
	        }
	    }
	    
	    public void completeProject(AdvertProject advproject)
	            throws Exception {
	        try {
	            begin();
	            System.out.println("inside DAO");
	            
	            getSession().update(advproject);
	                        
	            commit();
	           // return project;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create user " + username, e);
	            throw new Exception("Exception while creating user: " + e.getMessage());
	        }
	    }
	    
	    
	    public List getProjectAssigned(long userid )
	            throws AdException{
	        try {
	            begin();
	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            
	            Query q = getSession().createQuery("from AdvertProject where status = 'Assigned' and userAssigned = :userAssigned  ");
	            q.setLong("userAssigned", userid);
	           //  AdvertProject advertprj = (AdvertProject) q.uniqueResult();
	            
	            List<AdvertProject> projectlist = q.list();
	            commit();
	            return projectlist;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    
	    public List onCompletion(long userid )
	            throws AdException{
	        try {
	            begin();
	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            
	            Query q = getSession().createQuery("from AdvertProject where userAssigned = :userAssigned  ");
	            q.setLong("userAssigned", userid);
	           //  AdvertProject advertprj = (AdvertProject) q.uniqueResult();
	            
	            List<AdvertProject> projectlist = q.list();
	            commit();
	            return projectlist;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    
	    
	    
	    
	    public List getProjectPosted(long userid )
	            throws AdException{
	        try {
	            begin();
	            
//	            Criteria criteria = getSession().createCriteria(AdvertProject.class);
//	            criteria.add(Restrictions.ne("userid",userid));
//	            List<AdvertProject> projectlist = criteria.list();
	            
	            Query q = getSession().createQuery("from AdvertProject where user = :user  ");
	            q.setLong("user", userid);
	           //  AdvertProject advertprj = (AdvertProject) q.uniqueResult();
	            
	            List<AdvertProject> projectlist = q.list();
	            commit();
	            return projectlist;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create advert", e);
	            throw new AdException("Exception while creating advert: " + e.getMessage());
	        }
	    }
	    
	    
	    
}
