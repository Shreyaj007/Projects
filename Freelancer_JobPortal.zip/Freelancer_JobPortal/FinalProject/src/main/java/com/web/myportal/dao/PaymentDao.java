package com.web.myportal.dao;

import org.hibernate.HibernateException;

import com.web.myportal.pojo.Payment;
import com.web.myportal.pojo.Role;
import com.web.myportal.pojo.User;

public class PaymentDao extends DAO{

	   
    
    public Payment create(Payment payment)
            throws Exception {
        try {
            begin();
            System.out.println("inside DAO");
            
        
            
           // Email email=new Email(emailId);
         //   User user=new User(username,password);
            
//            user.setFirstName(firstName);
//            user.setLastName(lastName);
//            user.setEmail(emailId);
            //user.setUsername(username);
            //user.setPassword(password);
           
          //  System.out.println("user valu names"+ user.getFirstName()+ " "+ user.getLastName()+" "+user.getEmail()+" "+user.getUsername()+" "+user.getPassword()+ " ");
          //  email.setUser(user);
            
            getSession().save(payment);
            
            System.out.println(" saved user ");
            
            commit();
            return payment;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create user " + username, e);
            throw new Exception("Exception while creating user: " + e.getMessage());
        }
    }

    
	
	
	
	
}
