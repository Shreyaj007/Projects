package com.web.myportal.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name="projectAdvertTable")
public class AdvertProject {

	@Id @GeneratedValue
	@Column(name="projectid", unique = true, nullable = false)
    private long projectid;
	
	//@Column(name="categoryname",nullable=true) //will stored in advert table
	private String categoryname;
	
	@Column(name="projectname")
    private String projectname;
	
	@Column(name="description")
    private String description;
	

    @Column(name="budget")
    private int budget;
    
    @Column(name="userAssigned")
    private long userAssigned;
    
    @Column(name="status")
    private String status;
	
	@Transient //will not be stored in advert table
    private String postedBy;
	
	//@OneToMany(fetch=FetchType.LAZY, mappedBy="advertproject")
	//private Set<SkillSet> skillset = new HashSet<SkillSet>();
 
    @ManyToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinColumn(name="user")
    private User user;
    
    //@ManyToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
    @JoinColumn(name="categoryid")
    private long category;
    
    @OneToMany(fetch=FetchType.LAZY, mappedBy="projectid")
    private Set<Bids> bidsPlaced = new HashSet<Bids>();
    
    public AdvertProject(String categoryname,String projectname, String message,int budget) {
    	this.categoryname=categoryname;
        this.projectname = projectname;
        this.description = message;
        this.budget =  budget;       
       // this.category = category_id;
       this.bidsPlaced = new HashSet<Bids>();
    }

    AdvertProject() {
    }

	public long getProjectid() {
		return projectid;
	}

	public void setProjectid(long projectid) {
		this.projectid = projectid;
	}

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getUserAssigned() {
		return userAssigned;
	}

	public void setUserAssigned(long userAssigned) {
		this.userAssigned = userAssigned;
	}

	public long getCategory() {
		return category;
	}

	public void setCategory(long category) {
		this.category = category;
	}

	public Set<Bids> getBidsPlaced() {
		return bidsPlaced;
	}

	public void setBidsPlaced(Set<Bids> bidsPlaced) {
		this.bidsPlaced = bidsPlaced;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public String getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPostedBy() {
		return postedBy;
	}

	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getBudget() {
		return budget;
	}

	public void setBudget(int budget) {
		this.budget = budget;
	}

//	public Set<Bids> getBidsPlaced() {
//		return bidsPlaced;
//	}
//
//	public void setBidsPlaced(Set<Bids> bidsPlaced) {
//		this.bidsPlaced = bidsPlaced;
//	}
//	
    
	
	
}
