package com.web.myportal;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.web.myportal.pojo.User;


public class UserValidator implements Validator{

	
	 private Pattern pattern;  
	 private Matcher matcher;  
	  
//	 private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"  
//	   + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";  
//	 String ID_PATTERN = "[0-9]+";  
//	 String STRING_PATTERN = "[a-zA-Z]+";  
//	
	
    public boolean supports(Class aClass)
    {
        return aClass.equals(User.class);
    }

    public void validate(Object obj,Errors errors)
    {
        User user = (User) obj;
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "error.invalid.user", "First Name Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "error.invalid.user", "Last Name Required"); 
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "error.invalid.email.emailId", "Email Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "error.invalid.user", "User Name Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.invalid.user", "Password Required");
        
        boolean flag = false;
      
        	  
//        	// input string conatains characters only  
//        	  if (!(user.getFirstName() != null && user.getFirstName().isEmpty())) {  
//        	   pattern = Pattern.compile(STRING_PATTERN);  
//        	   matcher = pattern.matcher(user.getFirstName());  
//        	   if (!matcher.matches()) {  
//        		// errors.rejectValue("username","error.invalid.user", "username name not proper");
//        	   }  
//        	  }  
        
        
    }

	
	
}
