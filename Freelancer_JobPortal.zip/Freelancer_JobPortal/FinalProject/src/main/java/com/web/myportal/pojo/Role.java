package com.web.myportal.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="roletable")
public class Role {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="roleid", unique = true, nullable = false)
    private long roleid;
	
	@Column(name="rolename")
    private String rolename;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="personID")
	private User user;

	public long getRoleid() {
		return roleid;
	}

	public void setRoleid(long roleid) {
		this.roleid = roleid;
	}

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
}
