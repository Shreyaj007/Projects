package com.web.myportal;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.myportal.dao.ProjectDAO;
import com.web.myportal.exception.AdException;
import com.web.myportal.pojo.AdvertProject;
import com.web.myportal.pojo.Bids;
import com.web.myportal.pojo.User;

@Controller
public class BidsController {

	@Autowired
	@Qualifier("bidsValidator")
	BidsValidator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}
	
	@RequestMapping(value="/placeBid.htm",method = RequestMethod.POST)
	public ModelAndView placeBid(@ModelAttribute("bids") Bids bids, BindingResult result,HttpServletRequest req) {

		ModelAndView mv = new ModelAndView();
		
		validator.validate(bids, result);
		if (result.hasErrors()) {
			
			System.out.println("validator");
			
			return mv;
		}

		//try {
			System.out.println("test");
			long projectid = Long.parseLong(req.getParameter("projectid"));
			
			System.out.println("projectid "+ bids.getProjectid());
			bids.setProjectid(projectid);
			
			HttpSession sessionhttp = req.getSession(false);		
			
			 User u = (User)sessionhttp.getAttribute("user");		
			 
			 User user1 = new User(u.getUsername(), u.getPassword());
			 user1.setEmail(u.getEmail());
			 user1.setFirstName(u.getFirstName());
			 user1.setLastName(u.getLastName());
			 user1.setPersonID(u.getPersonID());
			 user1.setRole(u.getRole());
			
			 bids.setUserId(user1.getPersonID());
			 
			ProjectDAO projectDao = new ProjectDAO();
			try {
								
				  AdvertProject project = projectDao.getProjectByPid(bids.getProjectid());
		            project.setStatus("Bid Placed");
		            
		            projectDao.placeBid(bids);
		            
		            mv.addObject("userInSession", user1.getPersonID());
				
			} catch (AdException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				List<AdvertProject> list = projectDao.browse(u.getPersonID());
				mv.addObject("projectlist",list);
			} catch (AdException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
			mv.setViewName("showProjects");
			mv.addObject("bids","bids placed");
			System.out.print("test1");
	return mv;
		
	}
	
	@RequestMapping(value="/placeBid.htm",method = RequestMethod.GET)
	public ModelAndView diverttoBid(@ModelAttribute("bids") Bids bids, HttpServletRequest req) {
		
		long projectid = Long.parseLong(req.getParameter("projectid"));
		System.out.println("projectid "+ projectid);
		
		ModelAndView mv = new ModelAndView();
		bids.setProjectid(projectid);
		mv.addObject("projectid",projectid);
		mv.setViewName("placeBid");
		
		HttpSession sessionhttp = req.getSession(false);		
		
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		 
		 mv.addObject("userInSession", user1.getPersonID());
		
		System.out.println("in divert to bid");
	return mv;
		
	}
	
	@RequestMapping(value="/viewBids.htm",method = RequestMethod.GET)
	public ModelAndView showBids(@ModelAttribute("bids") Bids bids, HttpServletRequest req) {
		
		String numregex = "^[0-9]+$";
		Pattern patternBidAmt = Pattern.compile(numregex);
		
		 Matcher matcher = patternBidAmt.matcher(String.valueOf(bids.getBidamount()));
		
		 boolean matches = matcher.matches();
		 
		 ModelAndView mv = new ModelAndView();
		 
		if(matches)
		{
		
		long projectid = Long.parseLong(req.getParameter("projectid"));
		System.out.println("projectid "+ projectid);
		
		
		
		ProjectDAO projectdao = new ProjectDAO();
		
		HttpSession sessionhttp = req.getSession(false);		

		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		
		
		try {
			List bidlist = projectdao.browseBids(projectid);
			AdvertProject prj = projectdao.getProjectByPid(projectid);
			System.out.println("size "+ bidlist.size());
			System.out.println("user posting the proj"+ prj.getUser());
			
			mv.addObject("userInSession", user1.getPersonID());
			mv.addObject("userPosting", prj.getUser().getPersonID());
			mv.addObject("projectid", projectid);
			mv.addObject("bidlist",bidlist);
			
			mv.setViewName("showBids");
			System.out.println("in divert to show bid");
			
		}
		catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		else
		{
			mv.setViewName("error");
		}
		
	return mv;
		
	}
	
	
	
//	
	
	
	
}
