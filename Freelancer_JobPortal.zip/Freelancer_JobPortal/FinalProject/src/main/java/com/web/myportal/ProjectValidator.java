package com.web.myportal;



import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.web.myportal.pojo.AdvertProject;
import com.web.myportal.pojo.User;

public class ProjectValidator implements Validator{
	
	   public boolean supports(Class aClass)
	    {
	        return aClass.equals(AdvertProject.class);
	    }

	@Override
	public void validate(Object obj, Errors errors) {
		// TODO Auto-generated method stub
		
		  AdvertProject project = (AdvertProject) obj;
	   //    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "categoryname", "error.invalid.advertproject", "Category Name Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "projectname", "error.invalid.advertproject", "Project Name Required"); 
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description", "error.invalid.advertproject", "Description Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "budget", "error.invalid.advertproject", "Budget Required");
	       // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "", "error.invalid.user", " Required");		
		
	}

}
