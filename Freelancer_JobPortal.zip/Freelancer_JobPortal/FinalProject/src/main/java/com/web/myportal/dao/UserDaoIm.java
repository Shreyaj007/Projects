package com.web.myportal.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.web.myportal.pojo.User;

public class UserDaoIm extends DAO{

	 public UserDaoIm() {
	    }

	    public User get(String username)
	            throws Exception {
	        try {
	            begin();
	            Query q = getSession().createQuery("from User where username = :username");
	            q.setString("username", username);
	            User user = (User) q.uniqueResult();
	            commit();
	            return user;
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not get user " + username, e);
	        }
	    }

	    public User isValidUser(String username,String password)
	            throws Exception {
	        try {
	            begin();
	            boolean flag = false;
	            System.out.println("in valid");
	            
	            Query q = getSession().createQuery("from User where username = :username and password = :password");
	            q.setString("username", username);
	            q.setString("password", password);
	            System.out.println("username "+ username);
	            System.out.println("password "+ password);
	            
	            User u = (User) q.uniqueResult();
	            commit();
	            
//	            if(u.getUsername().equals(username) && u.getPassword().equals(password))
//	            {
//	            	flag = true;
//	            }
	          
	            return u;
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not get user " + username, e);
	        }
	    }
	    
	    
	    
	    public User create(User user)
	            throws Exception {
	        try {
	            begin();
	            System.out.println("inside DAO");
	            
	            
	           // Email email=new Email(emailId);
	         //   User user=new User(username,password);
	            
//	            user.setFirstName(firstName);
//	            user.setLastName(lastName);
//	            user.setEmail(emailId);
	            //user.setUsername(username);
	            //user.setPassword(password);
	           
	          //  System.out.println("user valu names"+ user.getFirstName()+ " "+ user.getLastName()+" "+user.getEmail()+" "+user.getUsername()+" "+user.getPassword()+ " ");
	          //  email.setUser(user);
	            
	            getSession().save(user);
	            
	            System.out.println(" saved user ");
	            
	            commit();
	            return user;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create user " + username, e);
	            throw new Exception("Exception while creating user: " + e.getMessage());
	        }
	    }

	    public void delete(User user)
	            throws Exception {
	        try {
	            begin();
	            getSession().delete(user);
	            commit();
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not delete user " + user.getUsername(), e);
	        }
	    }
	
	
	
}
