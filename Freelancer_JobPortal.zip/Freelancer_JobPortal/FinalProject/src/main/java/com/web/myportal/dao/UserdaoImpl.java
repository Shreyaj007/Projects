package com.web.myportal.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.web.myportal.pojo.Role;
import com.web.myportal.pojo.User;

public class UserdaoImpl extends DAO{

	 public UserdaoImpl() {
	    }

	    public User get(String username)
	            throws Exception {
	        try {
	            begin();
	            Query q = getSession().createQuery("from User where username = :username");
	            q.setString("username", username);
	            User user = (User) q.uniqueResult();
	            commit();
	            return user;
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not get user " + username, e);
	        }
	    }

	    public User isValidUser(String username,String password)
	            throws Exception {
	        try {
	            begin();
	            boolean flag = false;
	            System.out.println("in valid");
	            
	            Query q = getSession().createQuery("from User where username = :username and password = :password");
	            q.setString("username", username);
	            q.setString("password", password);
	            System.out.println("username "+ username);
	            System.out.println("password "+ password);
	            
	            User u = (User) q.uniqueResult();
	            commit();
	            
//	            if(u.getUsername().equals(username) && u.getPassword().equals(password))
//	            {
//	            	flag = true;
//	            }
	          
	            return u;
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not get user " + username, e);
	        }
	    }
	    
	    
	    
	    public User create(User user)
	            throws Exception {
	        try {
	            begin();
	            System.out.println("inside DAO");
	            
	            Role role = new Role();
	            role.setRolename("Role_User");
	            role.setUser(user);
	            user.setRole(role);
	            
	           // Email email=new Email(emailId);
	         //   User user=new User(username,password);
	            
//	            user.setFirstName(firstName);
//	            user.setLastName(lastName);
//	            user.setEmail(emailId);
	            //user.setUsername(username);
	            //user.setPassword(password);
	           
	          //  System.out.println("user valu names"+ user.getFirstName()+ " "+ user.getLastName()+" "+user.getEmail()+" "+user.getUsername()+" "+user.getPassword()+ " ");
	          //  email.setUser(user);
	            
	            getSession().save(user);
	            
	            System.out.println(" saved user ");
	            
	            commit();
	            return user;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create user " + username, e);
	            throw new Exception("Exception while creating user: " + e.getMessage());
	        }
	    }

	    
	    
	    
//	    public User updateChanges(User user)
//	            throws Exception {
//	        try {
//	            begin();
//	            System.out.println("inside DAO");	            
//	            getSession().update(user);	
//	            
//	            
//	            System.out.println("saved user "+ user.getFirstName()+ "ln "+ user.getLastName()+ " emai "+ user.getEmail()+"username  "+user.getUsername()+ "path "+ user.getPath());	            
//	            commit();
//	            return user;
//	        } catch (HibernateException e) {
//	            rollback();
//	            //throw new AdException("Could not create user " + username, e);
//	            throw new Exception("Exception while creating user: " + e.getMessage());
//	        }
//	    }
//	    
//	    
	    public User getUserDetails(User u) throws Exception
	    {
	        try {
	            begin();
	            Query q = getSession().createQuery("from User where personID = :userid");
	            q.setLong("userid", u.getPersonID());
	           User user = (User) q.uniqueResult();
	           // List userlist = q.list();
	            commit();
	            return user;
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not get list");
	        }
	    }
	    
	    
	    
	    
	    public void delete(User user)
	            throws Exception {
	        try {
	            begin();
	            getSession().delete(user);
	            commit();
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not delete user " + user.getUsername(), e);
	        }
	    }
	
	
	
	
}
