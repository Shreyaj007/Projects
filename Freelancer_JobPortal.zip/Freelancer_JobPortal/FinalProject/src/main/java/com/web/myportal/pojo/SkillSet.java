package com.web.myportal.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//@Entity
//@Table(name="skillsettable")
public class SkillSet {

	@Id @GeneratedValue
	@Column(name="skillId", unique = true, nullable = false)
	private int skillId;
	
	@Column(name="skillname")
	private String skillname;
	
	
	
	
	
}
