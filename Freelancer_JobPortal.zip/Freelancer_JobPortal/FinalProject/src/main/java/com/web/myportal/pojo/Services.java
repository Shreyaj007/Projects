package com.web.myportal.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


public class Services {
//
//	@Id 
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name="serviceid", unique = true, nullable = false)
//    private long serviceid;
//	
//	@Column(name="serviceType")
//	private String serviceType;
//	
//	@Column(name="serviceName")
//	private String serviceName;
//	
//	@Column(name="serviceCost")
//	private String serviceCost;
//	
//	@Column(name="description")
//	private String description;
//	
//	//many to many?
//	private Set<AdvertProject> projects = new HashSet<AdvertProject>();
//	
	
	
	
}
