package com.web.myportal;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.myportal.dao.ProjectDAO;
import com.web.myportal.exception.AdException;
import com.web.myportal.pojo.AdvertProject;
import com.web.myportal.pojo.User;

@Controller
public class AdminController {

	
	@RequestMapping(value="/approveProject.htm",method = RequestMethod.GET)
	protected ModelAndView doSubmitAction(@ModelAttribute("advertproject")AdvertProject advertproject, BindingResult result,HttpServletRequest req) throws Exception {

			ModelAndView mv = new ModelAndView();
		
		//try {
			System.out.println("test");
			ProjectDAO projectDao = new ProjectDAO();
			System.out.print("test1");
			
			long projectid = advertproject.getProjectid();
			
			AdvertProject project = projectDao.getProjectByPid(projectid);
			project.setStatus("Approved");
	
			projectDao.approveProject(project);
				
			HttpSession sessionhttp = req.getSession(false);		
			
			 User u = (User)sessionhttp.getAttribute("admin");		
			 
			 User user1 = new User(u.getUsername(), u.getPassword());
			 user1.setEmail(u.getEmail());
			 user1.setFirstName(u.getFirstName());
			 user1.setLastName(u.getLastName());
			 user1.setPersonID(u.getPersonID());
			 user1.setRole(u.getRole());
			
			 mv.addObject("adminInSession", user1.getPersonID());
			
			
			List<AdvertProject> list = projectDao.getProjectToBeApproved();
			mv.addObject("projectlist", list);
			mv.setViewName("displayProjects");
			// DAO.close();
//		} catch (Exception e) {
//			System.out.println("Exception: " + e.getMessage());
//		}

		return mv;
	}
	
	
	@RequestMapping(value="/approveProjects.htm",method = RequestMethod.GET)
	protected ModelAndView doBrowseAction(HttpServletRequest req) {
		
		ProjectDAO projectdao = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
				
		try {
			List<AdvertProject> list = projectdao.getProjectToBeApproved();
			mv.addObject("projectlist", list);
			System.out.println("projectlist");
			//mv.addObject("userInSession", user1.getPersonID());
			
					
			mv.setViewName("displayProjects");
		} catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return mv;
	}
	
	@RequestMapping(value="/approvedProjects.htm",method = RequestMethod.GET)
	protected ModelAndView showApprovedProjectsAction(HttpServletRequest req) {
		
		ProjectDAO projectdao = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
				
		try {
			List<AdvertProject> list = projectdao.getProjectApproved();
			mv.addObject("projectlist", list);
			System.out.println("projectlist");
			//mv.addObject("userInSession", user1.getPersonID());
			
					
			mv.setViewName("displayProjects");
		} catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return mv;
	}
	
	
	
	@RequestMapping(value="/showAllProjects.htm",method = RequestMethod.GET)
	protected ModelAndView doBrowse(HttpServletRequest req) {
		
		ProjectDAO projectdao = new ProjectDAO();
		ModelAndView mv = new ModelAndView();
//		HttpSession sessionhttp = req.getSession(false);		
//		
//		 User u = (User)sessionhttp.getAttribute("user");		
//		 
//		 User user1 = new User(u.getUsername(), u.getPassword());
//		 user1.setEmail(u.getEmail());
//		 user1.setFirstName(u.getFirstName());
//		 user1.setLastName(u.getLastName());
//		 user1.setPersonID(u.getPersonID());
//		 user1.setRole(u.getRole());
		
		try {
			List<AdvertProject> list = projectdao.browseAll();
			mv.addObject("projectlist", list);
			System.out.println("projectlist");
			//mv.addObject("userInSession", user1.getPersonID());
						
			
			mv.setViewName("displayProjects");
		} catch (AdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return mv;
	}
	
	
	
	
	
	
}
