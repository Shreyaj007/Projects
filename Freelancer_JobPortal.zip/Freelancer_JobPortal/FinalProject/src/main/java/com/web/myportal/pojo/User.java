package com.web.myportal.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;



@Entity
@Table(name="usertable")
@PrimaryKeyJoinColumn(name="personID")

public class User extends Person{

	//@Pattern(regexp="")
	@Column(name="username")
    private String username;
	

	@Column(name="password")
    private String password;
	
	@Column(name="path")
	private String path;
	
	//@OneToOne(fetch=FetchType.EAGER, mappedBy="user", cascade=CascadeType.ALL)
	//@Pattern(regexp=".+@.+\\.[a-z]+")
	@Column(name="email")
    private String email;
	
	@OneToOne(fetch=FetchType.EAGER, mappedBy="user", cascade=CascadeType.ALL)
	//@Column(name="role")
	private Role role;	
	
	
	@OneToMany(fetch=FetchType.EAGER, mappedBy="user")
	private Set<AdvertProject> projects = new HashSet<AdvertProject>();

	@OneToMany(fetch=FetchType.EAGER, mappedBy="user")
	private Set<Payment> payment = new HashSet<Payment>();
	
	//@OneToMany(fetch=FetchType.EAGER, mappedBy="user")
	//private Set<Bids> bids = new HashSet<Bids>();
	 

	public User(String username, String password) {
        this.username = username;
        this.password = password;
       this.projects = new HashSet<AdvertProject>();
       this.payment = new HashSet<Payment>();
        //this.bids = new HashSet<Bids>();
    }

    User() {
    }

    
    
    public Set<Payment> getPayment() {
		return payment;
	}

	public void setPayment(Set<Payment> payment) {
		this.payment = payment;
	}



	public String getPath() {
 		return path;
 	}

 	public void setPath(String path) {
 		this.path = path;
 	}
    
    public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Set<AdvertProject> getProjects() {
		return projects;
	}

	public void setProjects(Set<AdvertProject> projects) {
		this.projects = projects;
	}

//    protected long getId() {
//        return id;
//    }
//
//    protected void setId(long id) {
//        this.id = id;
//    }

    
    
    
    
    
//	public Email getEmail() {
//		return email;
//		
//	}
//
//	public void setEmail(Email email) {
//		this.email = email;
//	}
//	
//	public Person getPerson() {
//		return person;
//	}
//
//	public void setPerson(Person person) {
//		this.person = person;
//	}
	
	
}
