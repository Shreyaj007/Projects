package com.web.myportal;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.web.myportal.pojo.Payment;


public class PaymentValidator implements Validator{

	@Override
	public boolean supports(Class aclass) {
		// TODO Auto-generated method stub
		return aclass.equals(Payment.class);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		// TODO Auto-generated method stub
		
		
		 Payment payment = (Payment) obj;
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "streetAddress", "error.invalid.payment", "First Name Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "city", "error.invalid.payment", "Last Name Required"); 
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "zipcode", "error.invalid.payment", "Email Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "error.invalid.payment", "User Name Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "card_firstName", "error.invalid.payment", "Password Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "card_lastName", "error.invalid.payment", "Password Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "card_lastName", "error.invalid.payment", "Password Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cardNumber", "error.invalid.payment", "Password Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "date", "error.invalid.payment", "Password Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cvv", "error.invalid.payment", "Password Required");
	      
		
	}

	
	
	
	
}
