package com.web.myportal;

import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.web.myportal.dao.AdminDao;
import com.web.myportal.dao.UserDaoIm;
import com.web.myportal.dao.UserdaoImpl;

import com.web.myportal.pojo.User;

@Controller
// @RequestMapping("/adduser.htm")
public class AddUserFormController implements ServletContextAware{

	@Autowired
	@Qualifier("userValidator")
	UserValidator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	
	private ServletContext servletContext;

	@RequestMapping(value = "/adduser.htm", method = RequestMethod.POST)
	protected ModelAndView doSubmitAction(@ModelAttribute("user") User user, BindingResult result) throws Exception {

		ModelAndView mv = new ModelAndView();
		
		validator.validate(user, result);
		if (result.hasErrors()) {

			System.out.println("validator");
			mv.setViewName("addUserForm");
			return mv;
		}
		
	String regexUserName = "/^[a-z0-9_-]{3,16}$/";
	String regexpassword = "/^[a-z0-9_-]{6,18}$/";
	String regexEmail = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
		+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	String textregex = "^[a-zA-Z\\s]+$";
	
	Pattern patternUserName = Pattern.compile(regexUserName);
	Pattern patternPassword = Pattern.compile(regexpassword);
	Pattern patternEmail = Pattern.compile(regexEmail);
	Pattern patternText = Pattern.compile(textregex);
	
	 Matcher matcherUserName = patternText.matcher(user.getUsername());
	 Matcher matcherPassword = patternText.matcher(user.getPassword());
	 Matcher matcherEmail = patternEmail.matcher(user.getEmail());
	 Matcher matcherFirstName = patternText.matcher(user.getFirstName());
	 Matcher matcherLastName = patternText.matcher(user.getLastName());
	 
	 boolean matches = (matcherUserName.matches() && matcherPassword.matches() && matcherEmail.matches() && matcherFirstName.matches() && matcherLastName.matches());
	 
	 System.out.println("username "+ matcherUserName.matches() + "password "+ matcherPassword.matches() +"email "+ matcherEmail.matches() + "firstname "+ matcherFirstName.matches() + "lastname "+ matcherLastName.matches());
	
	 if(matches )
	 { 
		user.setPath("N/A");
		
		System.out.println("test");
		UserdaoImpl userDao = new UserdaoImpl();
		System.out.print("test1");

		userDao.create(user);
		mv.setViewName("addedUser");
	 }
	 else
	 {
		 mv.setViewName("error");
	 }
		return mv;
	}

	@RequestMapping(value = "/logout.htm", method = RequestMethod.GET)
	protected ModelAndView logoutAction(@ModelAttribute("user") User user, BindingResult result,HttpServletRequest req)
		{
		HttpSession session = req.getSession(false);
		session.invalidate();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");		
		return mv; 
		}
	
	
	@RequestMapping(value = "/displayProfilePage.htm", method = RequestMethod.GET)
	protected ModelAndView displayProfileAction(@ModelAttribute("user") User user, BindingResult result,HttpServletRequest req)
		{
		UserdaoImpl userdao = new UserdaoImpl();
		ModelAndView mv = new ModelAndView();
		
		HttpSession sessionhttp = req.getSession(false);        
		 
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		 
		try {
			User usr = userdao.getUserDetails(user1);
			mv.addObject("user",usr);
			mv.addObject("userInSession", user1.getPersonID());
					
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		mv.setViewName("displayProfilePage");
		
		return mv;
		
		
		}
	
	@RequestMapping(value = "/saveChanges.htm", method = RequestMethod.POST)
	protected ModelAndView saveChangesAction(@ModelAttribute("user") User user, BindingResult result,
			@RequestParam(value = "displaypic", required = false) MultipartFile displaypic,HttpServletRequest req) throws Exception {
	
		ModelAndView mv = new ModelAndView();
		
		System.out.println(displaypic);
		if(!displaypic.isEmpty())
		{
			//validateImage(displaypic);
			
			
			
		saveDisplayPic(user.getFirstName()+".jpg",displaypic);
		
		user.setPath("resources/img/dashboard/"+user.getFirstName()+".jpg");
		System.out.println("path "+user.getPath());
		}
		else
		{
			user.setPath("N/A");
		}
		// try {
		System.out.println("test");
	
		
		HttpSession sessionhttp = req.getSession(false);        
		 
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(user.getUsername(), user.getPassword());
		 user1.setEmail(user.getEmail());
		 user1.setFirstName(user.getFirstName());
		 user1.setLastName(user.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		user1.setPath(user.getPath());
		System.out.println("path "+user1.getPath());
		 user.setRole(user1.getRole());
		 
		 
		 
		AdminDao userDao = new AdminDao();
		System.out.print("test1");

		// user.getRole().setRolename("Role_User");
		// userDao.create(user.getName(), user.getPassword(), user.getEmail(),
		// user.getFirstName(), user.getLastName());
		
		System.out.println(u.getPersonID());
		int a =userDao.updateChanges(user1.getPath(),user1.getPersonID());
		
		System.out.println(" rows executed "+ a);
		mv.addObject("userInSession", user1.getPersonID());
		// DAO.close();
		// } catch (Exception e) {
		// System.out.println("Exception: " + e.getMessage());
		// }

		mv.setViewName("displayProfilePage");
		
		return mv;
	}

	
	private void validateImage(MultipartFile displaypic)
	{
		if(displaypic.getContentType().equals("image/jpeg"))
		{
			throw new RuntimeException("Only jpeg are accepted");
		}
		
	}
	
	private void saveDisplayPic(String path, MultipartFile displaypic)
	{
		File file = new File(servletContext.getRealPath("/")+"resources/img/dashboard/"+path);
		
		
		
		try {
			FileUtils.writeByteArrayToFile(file, displaypic.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	@RequestMapping(value = "/adduser.htm", method = RequestMethod.GET)
	public String initializeForm(@ModelAttribute("user") User user, BindingResult result) {

		return "addUserForm";
	}
	
	
	@RequestMapping(value = "/userHomePage.htm", method = RequestMethod.GET)
	public ModelAndView userHomeForm(@ModelAttribute("user") User user, BindingResult result,HttpServletRequest req) {

		ModelAndView mv = new ModelAndView();
		HttpSession sessionhttp = req.getSession(false);        
		 
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
		
		mv.addObject("userInSession", user1.getPersonID());
			
		mv.setViewName("UserHomePage");
		return mv;
	}
	
	@RequestMapping(value = "/HomePage.htm", method = RequestMethod.GET)
	public ModelAndView HomeForm(@ModelAttribute("user") User user, BindingResult result,HttpServletRequest req) {

		ModelAndView mv = new ModelAndView();
					
		mv.setViewName("home");
		return mv;
	}
	
	@RequestMapping(value = "/admin.htm", method = RequestMethod.GET)
	public ModelAndView AdminHomeForm(HttpServletRequest req) {

		ModelAndView mv = new ModelAndView();
					
		mv.setViewName("Admin");
		return mv;
	}

	@RequestMapping(value = "/signInUser.htm", method = RequestMethod.POST)
	protected ModelAndView doSignInAction(@ModelAttribute("user") User user, BindingResult result, HttpServletRequest req)
			throws Exception {
		// validator.validate(user, result);
		// if (result.hasErrors()) {
		//
		// System.out.println("validator");
		//
		// return "UserHomePage";
		// }
		String page = null;
		// try {
		System.out.println("test");
		ModelAndView mv = new ModelAndView();
		
		UserDaoIm userDao = new UserDaoIm();
		System.out.print("test1");

		// userDao.create(user.getName(), user.getPassword(), user.getEmail(),
		// user.getFirstName(), user.getLastName());
		User usr = userDao.isValidUser(user.getUsername(), user.getPassword());
		// userDao.create(user.getFirstName(), user.getLastName(),
		// user.getEmail(),user.getUsername(), user.getPassword());
		
		
		ApplicationContext context = 
	            new ClassPathXmlApplicationContext("Spring-Mail.xml");
	   	 
	   	
		
		
		if(usr!=null)
		{
		if (usr.getRole().getRolename().equals("Role_User")) {
			
			HttpSession sessionhttp = req.getSession();
			sessionhttp.setAttribute("user", usr);		
			User u = (User)sessionhttp.getAttribute("user");				 
			 User user1 = new User(u.getUsername(), u.getPassword());
			 user1.setEmail(u.getEmail());
			 user1.setFirstName(u.getFirstName());
			 user1.setLastName(u.getLastName());
			 user1.setPersonID(u.getPersonID());
			 user1.setRole(u.getRole());
			
			 mv.addObject("user", user1);
			 
			page = "UserHomePage";
			mv.setViewName("UserHomePage");
		}
		else if(usr.getRole().getRolename().equals("Role_Admin"))
			{
			
			HttpSession sessionhttp = req.getSession();
			sessionhttp.setAttribute("admin", usr);		
			User u = (User)sessionhttp.getAttribute("admin");				 
			 User user1 = new User(u.getUsername(), u.getPassword());
			 user1.setEmail(u.getEmail());
			 user1.setFirstName(u.getFirstName());
			 user1.setLastName(u.getLastName());
			 user1.setPersonID(u.getPersonID());
			 user1.setRole(u.getRole());
			
			 mv.addObject("admin", user1);
			
			page = "Admin";
			mv.setViewName("Admin");			
			
			}
			else {
			
			page = "error";
			mv.setViewName("error");
		}
		
		}
		return mv;

	}

	@RequestMapping(value = "/signInUser.htm", method = RequestMethod.GET)
	public String initializeSignInForm(@ModelAttribute("user") User user, BindingResult result) {

		return "signIn";
	}
	

	@RequestMapping(value = "/verifyUser.htm", method = RequestMethod.GET)
	public String SignInForm(@ModelAttribute("user") User user, BindingResult result,HttpServletRequest req) {

	
		
		
		
		return "signIn";
	}
	

	@RequestMapping(value = "/signInAsAdmin.htm", method = RequestMethod.GET)
	public ModelAndView adminPage(@ModelAttribute("user") User user, BindingResult result) {

		ModelAndView model = new ModelAndView();
				
		//model.addObject("message", "This is protected page!");
		model.setViewName("signIn");

		return model;
	}

	@Override
	public void setServletContext(ServletContext servletContext) {
		// TODO Auto-generated method stub
		this.servletContext = servletContext;
		
	}

	@RequestMapping(value="sendMail.htm", method = RequestMethod.GET)
	public void mailSend()
	{
	ApplicationContext context = 
            new ClassPathXmlApplicationContext("Spring-Mail.xml");
   	 
   	Mail mm = (Mail) context.getBean("mailMail");
       mm.sendMail("joshi.shreya.007@gmail.com",
   		   "joshi.sh@husky.neu.edu",
   		   "hi", 
   		   "hello");
       
	
	}
	
	
}
