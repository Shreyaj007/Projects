package com.web.myportal.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="bidstable")
public class Bids {


	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="bidId", unique = true, nullable = false)
    private long bidId;
	
	@Column(name="bidAmount")
	private int bidamount;
	
	@Column(name="timeProject")
	private int timeRequired;
	
	//@ManyToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="projectid")
    private long projectid;
	
	@Column(name="userId")
	private long userId;
	
	
	
	//@ManyToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)  
	//@JoinColumn(name="user")
    //private User user;

    public Bids(int bidamount,int bidtime,long projectid) {
    	this.bidamount=bidamount;
        this.timeRequired = bidtime;
        this.projectid = projectid;
       
    }
	
    public Bids()
    {
    	
    }
	
    
    
    
    
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getBidId() {
		return bidId;
	}

	public void setBidId(long bidId) {
		this.bidId = bidId;
	}



	public int getBidamount() {
		return bidamount;
	}

	public void setBidamount(int bidamount) {
		this.bidamount = bidamount;
	}

	public int getTimeRequired() {
		return timeRequired;
	}

	public void setTimeRequired(int timeRequired) {
		this.timeRequired = timeRequired;
	}

	public long getProjectid() {
		return projectid;
	}

	public void setProjectid(long projectid) {
		this.projectid = projectid;
	}
	
//	public User getUser() {
//		return user;
//	}
//
////	public AdvertProject getProject() {
////		return project;
////	}
////
////
////	public void setProject(AdvertProject project) {
////		this.project = project;
////	}
//
//
//	public void setUser(User user) {
//		this.user = user;
//	}
    
    
    
}
