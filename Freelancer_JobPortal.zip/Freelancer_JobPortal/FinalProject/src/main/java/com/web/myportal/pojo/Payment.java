package com.web.myportal.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="paymentTable")
public class Payment {

	@Id @GeneratedValue
	@Column(name="paymentid", unique = true, nullable = false)
    private long paymentid;
	
	@Column(name="streetAddress")
	private String streetAddress;
	
	@Column(name="city")
	private String city;
	
	@Column(name="zipcode")
	private String zipcode;
	
	@Column(name="email")
	private String email;
	
	@Column(name="card_firstName")
	private String card_firstName;
	
	@Column(name="card_lastName")
	private String card_lastName;
	
	@Column(name="cardNumber")
	private int cardNumber;
	
	@Column(name="date")
	private int date;
	
	@Column(name="cvv")
	private int cvv;
	
	@Column(name="projectid")
	private long projectid;
	
	@Column(name="recipient")
	private String recipient;
	
	@ManyToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinColumn(name="user")
	private User user;

	public long getPaymentid() {
		return paymentid;
	}

	public void setPaymentid(long paymentid) {
		this.paymentid = paymentid;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCard_firstName() {
		return card_firstName;
	}

	public void setCard_firstName(String card_firstName) {
		this.card_firstName = card_firstName;
	}

	public String getCard_lastName() {
		return card_lastName;
	}

	public void setCard_lastName(String card_lastName) {
		this.card_lastName = card_lastName;
	}

	public int getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
	}

	public int getDate() {
		return date;
	}

	public void setDate(int date) {
		this.date = date;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
	
	
	
}
