package com.web.myportal;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.myportal.dao.PaymentDao;

import com.web.myportal.pojo.Payment;
import com.web.myportal.pojo.User;


@Controller
public class PaymentController {

	@Autowired
	@Qualifier("paymentValidator")
	PaymentValidator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}
	
	
	@RequestMapping(value = "/makePayment.htm", method = RequestMethod.GET)
	public String initializeForm(@ModelAttribute("payment") Payment payment, BindingResult result) {

		return "MakePayment";
	}
	
	@RequestMapping(value = "/makePayment.htm", method = RequestMethod.POST)
	public ModelAndView makePayment(@ModelAttribute("payment") Payment payment, BindingResult result,HttpServletRequest req) {

		ModelAndView mv = new ModelAndView();
		validator.validate(payment, result);
		if (result.hasErrors()) {

			System.out.println("validator");
			mv.setViewName("MakePayment");
			return mv;
		}
		
		String numregex = "^[0-9]+$";
		String textregex = "^[a-zA-Z\\s]+$";
		String regexEmail = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		
		Pattern patternText = Pattern.compile(textregex);
		Pattern patternNum = Pattern.compile(numregex);
		Pattern patternEmail = Pattern.compile(regexEmail);
		
		
		 Matcher matcherStrtAddr = patternText.matcher(payment.getStreetAddress());
		 Matcher matcherCity = patternText.matcher(payment.getCity());
		 Matcher matcherFN = patternText.matcher(payment.getCard_firstName());
		 Matcher matcherLN = patternText.matcher(payment.getCard_lastName());
		 Matcher matcherCardNum = patternNum.matcher(String.valueOf(payment.getCardNumber())); 
		 Matcher matcherZPC = patternNum.matcher(String.valueOf(payment.getZipcode())); 
		 Matcher matcherCVV = patternNum.matcher(String.valueOf(payment.getCvv())); 
		 Matcher matcherEmail = patternEmail.matcher(String.valueOf(payment.getCardNumber())); 
		 
		
		 boolean matches = (matcherCardNum.matches() && matcherCVV.matches() && matcherZPC.matches() && matcherCity.matches() && matcherFN.matches() && matcherLN.matches() && matcherStrtAddr.matches() && matcherEmail.matches() );
		
		if(matches)
		{
		
		
		
		System.out.println("test");
		PaymentDao paymentDao = new PaymentDao();
		System.out.print("test1");

		HttpSession sessionhttp = req.getSession(false);
		//AdvertProject advertprojectt = new AdvertProject(advertproject.getCategoryname(), advertproject.getProjectname(),advertproject.getDescription(),advertproject.getBudget());
            
		 
		 User u = (User)sessionhttp.getAttribute("user");		
		 
		 User user1 = new User(u.getUsername(), u.getPassword());
		 user1.setEmail(u.getEmail());
		 user1.setFirstName(u.getFirstName());
		 user1.setLastName(u.getLastName());
		 user1.setPersonID(u.getPersonID());
		 user1.setRole(u.getRole());
				 
		 payment.setUser(user1);
		//advertproject.setStatus("posted/pendingApproval");
		mv.setViewName("PaymentDone");
		
		try {
			paymentDao.create(payment);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		else
		{
			HttpSession sessionhttp = req.getSession(false);
			sessionhttp.invalidate();
			mv.setViewName("error");
		}
		return mv;
	
	}
	
}
