package com.web.myportal.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.web.myportal.pojo.User;

public class AdminDao extends DAO{

	   public int updateChanges(String path, long personID)
	            throws Exception {
	        try {
	            begin();
	            System.out.println("inside DAO");
	            System.out.println("path "+ path);
	            System.out.println("id "+ personID);
	            Query q = getSession().createSQLQuery("UPDATE usertable SET path= :path WHERE personID = :personID ");
	            q.setString("path", path );
	            q.setLong("personID", personID);
	            int a = q.executeUpdate();
	            //System.out.println("saved user "+ user.getFirstName()+ "ln "+ user.getLastName()+ " emai "+ user.getEmail()+"username  "+user.getUsername()+ "path "+ user.getPath());	            
	            commit();
	            return a;
	        } catch (HibernateException e) {
	            rollback();
	            //throw new AdException("Could not create user " + username, e);
	            throw new Exception("Exception while creating user: " + e.getMessage());
	        }
	    }
	    
	    
	    public User getUserDetails(User u) throws Exception
	    {
	        try {
	            begin();
	            Query q = getSession().createQuery("from User where personID = :userid");
	            q.setLong("userid", u.getPersonID());
	           User user = (User) q.uniqueResult();
	           // List userlist = q.list();
	            commit();
	            return user;
	        } catch (HibernateException e) {
	            rollback();
	            throw new Exception("Could not get list");
	        }
	    }
	
	
}
